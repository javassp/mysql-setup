
"use strict"

function validationinquiry() {    
    var firstname = document.forms["inquiryForm"]["fname"].value;
    var secondname = document.forms["inquiryForm"]["lname"].value;
    var emailid = document.forms["inquiryForm"]["email"].value;

    if(firstname == ""){
        alert("First Name should not empty");
    } else if(secondname == "")    {
        alert("Last Name should not empty");
    }else if(emailid == ""){
        alert("Email should not empty");
    }



}